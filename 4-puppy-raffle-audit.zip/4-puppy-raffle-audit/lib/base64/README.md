# base64

base64 encoding in solidity.
